/*3. Modificar la última tarea para realizarla mediante una función llamada mostrarMensajes  contenida en un fichero js externo.*/
let boton1 = document.getElementById("btn");
boton1.addEventListener("click", mostrarMensajes);

/*4. Solicita el precio de un producto y calcula el precio final aplicando un IVA del 21%. */
/*5. Solicita tres números y muestra cuál es el mayor.*/
/*6. Solicita una nota entre 0 y 10 y muestra Suspenso, Aprobado, Bien, Notable o Sobresaliente.  Valida el rango.*/
/*7. El usuario debe introducir dos números y un operador y visualizar el resultado de la  operación. Las operaciones serán +, -, *, /. */
let boton2 = document.getElementById("btn2");
boton2.addEventListener("click", mostrarMensajes2);

/*8. Solicita un número y muestra su tabla de multiplicar.*/
let boton3 = document.getElementById("btn3");
boton3.addEventListener("click", mostrarMensajes3);

/*9. Escribe la tabla de multiplicar de todos los números del 1 al 10.*/
let boton4 = document.getElementById("btn4");
boton4.addEventListener("click", tablasMultiplicar);

/*10. Crea una función que indique si un número es par. Utiliza una función flecha.*/
/*11. Visualiza los números pares que hay dentro de los 100 primeros números enteros. Llama a la  función creada en el ejercicio anterior.*/
let boton5 = document.getElementById("btn5");
boton5.addEventListener("click", muestraMensaje4);

/*12. Calcula y muestra la suma de todos los números del 1 al 100.*/
let boton6 = document.getElementById("btn6");
boton6.addEventListener("click", sumaNumeros);

/*13. Crea y llama a una función flecha que recibe la base y la altura de un triángulo y devuelva  su área. Recoger el valor devuelto y muéstralo con console.log. (Área triángulo = base*altura/2)*/
let boton7 = document.getElementById("btn7");
boton7.addEventListener("click", AreaTriangulo);

/*14. Crea una página que pida cinco números y muestre su suma. */
let boton8 = document.getElementById("btn8");
boton8.addEventListener("click", sumade5);

/*15. Crea una página que pida números hasta que se introduzca un cero y muestre la suma de todos*/
let boton9 = document.getElementById("btn9");
boton9.addEventListener("click", hasta0);

function mostrarMensajes() {
            alert("¡Hola! Has hecho clic en el botón.");
            console.log("Botón clickeado");
            console.error("Esto es un mensaje de error en la consola");
        };
function mostrarMensajes2() {
    let precio = prompt("Introduce el precio del producto: ");
    console.log("Precio introducido: " + precio);
    console.log("Precio + IVA: " + precio * 1.21);

    console.log("Introduce tres números: ");
    let num1 = parseFloat(prompt("Número 1: "));
    let num2 = parseFloat(prompt("Número 2: "));
    let num3 = parseFloat(prompt("Número 3: "));
    if (num1 >= num2 && num1 >= num3) {
        console.log("El número mayor es: " + num1);
    }else if (num2 >= num1 && num2 >= num3) {
        console.log("El número mayor es: " + num2);
    }else {
        console.log("El número mayor es: " + num3);
    }

    let nota = prompt("Introduce una nota: ");
    if (nota < 5 && nota >= 0){
        console.log("¡Suspenso!");
    }else if ( nota == 5){
        console.log("¡Suficiente!");
    }else if (nota == 6){
        console.log("¡Bien!");
    }else if (nota == 7 || nota == 8){
        console.log("¡Notable!");
    }else if (nota == 9 || nota == 10){
        console.log("¡Sobresaliente!");
    }else {
        console.log("¡Nota no válida!");
    }

    console.log("Introduce dos números y un operador: ");
    let num4 = parseFloat(prompt("Número 1: "));
    let num5 = parseFloat(prompt("Número 2: "));
    let operador = prompt("Operador (+, -, *, /): ");
    if (operador == "+"){
        console.log("Resultado: " + (num4 + num5));
    }else if (operador == "-"){
        console.log("Resultado: " + (num4 - num5));
    }else if (operador == "*"){
        console.log("Resultado: " + (num4 * num5));
    }else if (operador == "/"){
        if (num5 == 0){
            console.log("Error: División por cero");
        }else {
            console.log("Resultado: " + (num4 / num5));
        }
    }else {
        console.log("Operador no válido");
    }
}
function mostrarMensajes3() {
    let numero = parseFloat(prompt("Introduce un número: "));
    for (let i = 1; i <= 10; i++) {
        console.log(numero + " x " + i + " = " + (numero * i));
    }
}
function tablasMultiplicar() {
    
    for (let i = 0; i <= 10; i++) {
        console.log("Tabla del " + i);
        for (let j = 0; j <= 10; j++) {
            console.log(i + " x " + j + " = " + (i * j));
        }
    }
}
function muestraMensaje4(){
    let numero = parseInt(prompt("Introduce un número: "));
    if (esPar(numero)) {
        console.log("El número " + numero + " es par.");
    }else{
        console.log("El número " + numero + " es impar.");
    }
    for (let i = 0; i <= 100; i++) {
        if (esPar(i)) {
            console.log(i + " es par.");
        }
    }
}
const esPar = numero => numero % 2 === 0;

function sumaNumeros() {
    let suma = 0;
    for (let i = 1; i <= 100; i++) {
        suma += i;
    }
    console.log("La suma de los primeros 100 números es: " + suma);
}
function AreaTriangulo() {
    let base = parseInt(prompt("Introduce la base del trinagulo: "));
    let altura = parseInt(prompt("Introduce la altura del triangulo: "));
    console.log("El área del triangulo es: " + AreaTri(base, altura));
}
const AreaTri = (base, altura) => (base * altura) / 2;

function sumade5(){
    let numero = parseInt(prompt("Dime un numero"));
    let numero2 = parseInt(prompt("Otro"));
    let numero3 = parseInt(prompt("Otro"));
    let numero4 = parseInt(prompt("Otro"));
    let numero5 = parseInt(prompt("El último"));
    let suma = numero + numero2 + numero3 + numero4 + numero5;
    console.log("La suma es : " + suma);
}

function hasta0(){
    let suma = 0;
    let num;
    do {
        num = parseInt(prompt("Dame numeros para sumar y pon 0 para salir"));
        suma += num;
    } while (num != 0);
    console.log("La suma de todos esos numeros es : " + suma);
}